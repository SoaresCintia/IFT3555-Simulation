package sim

import munit.FunSuite

class AlloTest extends FunSuite {
  test("ok") {
    assertEquals(true, false)
  }
}
